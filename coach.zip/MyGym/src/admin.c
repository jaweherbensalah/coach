#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <gtk/gtk.h>

#include "admin.h"
#include "login.h"

enum{
	ID,
	NOM,
	PRENOM,
	DDN,
	VILLE,
	ZIP,
	ADRESSE,
	TEL,
	COLUMNS
};


void add_user(char login[], char password[],int role)
{
	int id = generateID();
	FILE *f;

	f=fopen("/home/jaweher/Desktop/MyGym/src/data/users.txt","a");
	if (f!=NULL)
	{
	fprintf(f,"%d %s %s %d\n",id,login,password,role);
	fclose(f);
	}
	else printf("ERROR : Cannot open file users\n");

}
//=============================================================================
void add_info(char id[],char nom[],char prenom[],int jour,int mois,int annee,char ville[],char postal[],char adresse[], long tel)
{
	FILE *user_info;
	// char SID[5];
	char path[100];

// strcpy(SID,"");
//	itoa(id,SID,10);

	strcpy(path,"/home/jaweher/Desktop/MyGym/src/data/");
	strcat(path,id);
	user_info=fopen(path,"w");

	fprintf(user_info,"%s %s %s %d %d %d %s %s %s %li\n",id, nom,prenom,jour,mois,annee,ville,postal,adresse,tel);
	fclose(user_info);
}
//=============================================================================
void show_users (GtkWidget *list)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	struct user u;


	store = NULL;

	FILE* f;

	store = gtk_tree_view_get_model(list);
	if (store == NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes ("ID",renderer, "3asba", ID, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (list),column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes ("NOM",renderer, "3asba2", NOM, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (list),column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes ("PRENOM",renderer, "3asba3", PRENOM, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (list),column);

//		renderer = gtk_cell_rendrer_text_new ();
//		column = gtk_tree_view_column_new_with_attributes ("DDN",renderer, "3asba4", DDN, NULL);
//		gtk_tree_view_append_column (GTK_TREE_VIEW (list),column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes ("VILLE",renderer, "3asba5", VILLE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (list),column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes ("ZIP",renderer, "3asba69", ZIP, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (list),column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes ("ADRESSSE",renderer, "3asba7", ADRESSE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (list),column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes ("TEL",renderer, "3asba71", TEL, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (list),column);

		store = gtk_list_store_new(COLUMNS,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_LONG);

		f=fopen("/home/jaweher/Desktop/MyGym/src/data/users","r");
		if (f == NULL){
			printf("ERROR : Could not open file users.\n");
			return;
		}else{
			f=fopen("/home/jaweher/Desktop/MyGym/src/data/users","a+");
			while(fscanf(f,"%d %s %s %d %d %d %s %s %s %li\n",&u.id, u.nom,u.prenom,&u.date_de_naissance.jj,&u.date_de_naissance.mm,&u.date_de_naissance.aaaa,u.ville,&u.postal,u.adresse,&u.tel)!=EOF)
			{
				gtk_list_store_append(store, &iter);
				gtk_list_store_set(store,&iter,NOM,u.nom,PRENOM,u.prenom,VILLE,u.ville,ZIP,u.postal,ADRESSE,u.adresse,TEL,u.tel, -1);
			}
			fclose(f);
			gtk_tree_view_set_model (GTK_TREE_VIEW(list), GTK_TREE_MODEL(store));
			g_object_unref(store);
		}
	}

}
//=============================================================================
int generateID(){
	int id,r_role,r_password,r_login,r_id;
	FILE* f;
	f=fopen("/home/jaweher/Desktop/MyGym/src/data/users","r");
	if(f!=NULL)
	{

		while (fscanf(f,"%d %s %s %d\n",&r_id,r_login,r_password,&r_role) != EOF)
		{
				id = r_id + 3;
		}
	}else{
		printf("ERROR : Could not open file users.\n");
	}
}
