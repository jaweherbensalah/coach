void add_user(char login[], char password[],int role);
void show_users ();
void add_info(char id[], char nom[],char prenom[],int jour,int mois,int annee,char ville[],char postal[],char adresse[],long tel);
void show_users (GtkWidget *list);
int generateID();
