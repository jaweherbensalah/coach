#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "callbacks.h"
#include "interface.h"

#include "support.h"
#include "login.h"
#include "admin.h"
#include "kine.h"
#include "rdv.h"

void
on_button_home_quit_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
  gtk_main_quit();
}


void
on_button_home_login_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
  char login[30];char password[30]; int role;int x;

	GtkWidget *input1=lookup_widget(objet_graphique,"entry_login");
	GtkWidget *input2=lookup_widget(objet_graphique,"entry_pwd");
	GtkWidget *output=lookup_widget(objet_graphique,"label_home_error");
	GtkWidget *window_home;
  GtkWidget *window_admin;
  GtkWidget *window_kine;
  GtkWidget *window_nutri;

	window_home=lookup_widget(objet_graphique,"window_home");



	strcpy(login,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(password,gtk_entry_get_text(GTK_ENTRY(input2)));

	x=check_login(login,password);

	switch(x){
    case 1 : {
        window_admin = create_window_admin();
        gtk_widget_destroy(window_home);
        gtk_widget_show(window_admin);
      }break;

    case 4 : {
        window_kine = create_window_kine();
        gtk_widget_destroy(window_home);
        gtk_widget_show(window_kine);
      }break;

    case 5 : {
        window_nutri = create_window_nutri();
        gtk_widget_destroy(window_home);
        gtk_widget_show(window_nutri);
      }break;

    case -1 : {
      	gtk_label_set_text(GTK_LABEL(output),"Nom d'utilisateur ou mot de passe incorrect !");
      }break;

      case -2 : {
        	gtk_label_set_text(GTK_LABEL(output),"Veuillez saisir un nom d'utilisateur !");
        }break;

      case -3 : {
          gtk_label_set_text(GTK_LABEL(output),"Veuillez saisir un mot de passe !");
        }break;


		default : printf("Error : unindentified role.\n");
		}

	}

void
on_button_admin_logout_clicked  (GtkWidget *objet_graphique, gpointer user_data)
{
  GtkWidget *window_home;
  GtkWidget *window_admin;
	window_admin=lookup_widget(objet_graphique,"window_admin");

  window_home = create_window_home();
  gtk_widget_destroy(window_admin);
  gtk_widget_show(window_home);
}


void
on_button_admin_refresh_clicked  (GtkWidget *objet_graphique, gpointer user_data)
{
  GtkWidget *window_admin;
  GtkWidget *treeview_admin;

  window_admin = lookup_widget(objet_graphique,"window_admin");
  treeview_admin = lookup_widget(window_admin,"treeview_admin");

 show_users (treeview_admin);
}


void
on_button_admin_del_clicked  (GtkWidget *objet_graphique, gpointer user_data)
{

}


void
on_button_admin_edit_clicked  (GtkWidget *objet_graphique, gpointer user_data)
{

}


void
on_button_admin_add_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
  GtkWidget *window_admin_add_user;
  window_admin_add_user = create_window_admin_add_user();
  gtk_widget_show(window_admin_add_user);
}

void
on_button_kine_patients_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
  GtkWidget *window_kine;
  GtkWidget *window_kine_patients;
  window_kine = lookup_widget(objet_graphique,"window_kine");
  window_kine_patients = create_window_kine_patients();

  GtkWidget *label_kine_add_patient_1;
  GtkWidget *entry_kine_add_patient;
  GtkWidget *button_kine_add_patient_validate;
  GtkWidget *button_kine_add_patient_end;
  GtkWidget *treeview_kine_patients;

  label_kine_add_patient_1 = lookup_widget(window_kine_patients,"label_kine_add_patient_1");
  entry_kine_add_patient = lookup_widget(window_kine_patients,"entry_kine_add_patient");
  button_kine_add_patient_validate = lookup_widget(window_kine_patients,"button_kine_add_patient_validate");
  button_kine_add_patient_end = lookup_widget(window_kine_patients,"button_kine_add_patient_end");
  treeview_kine_patients = lookup_widget(window_kine_patients,"treeview_kine_patients");
  kine_show_patients(treeview_kine_patients);

  gtk_widget_show(window_kine_patients);
  gtk_widget_hide(label_kine_add_patient_1);
  gtk_widget_hide(entry_kine_add_patient);
  gtk_widget_hide(button_kine_add_patient_validate);
  gtk_widget_hide(button_kine_add_patient_end);
  gtk_widget_destroy(window_kine);

}


void
on_button_kine_logout_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
  GtkWidget *window_home;
  GtkWidget *window_kine;
  window_kine = lookup_widget(objet_graphique,"window_kine");
  gtk_widget_destroy(window_kine);
  window_home = create_window_home();
  gtk_widget_show(window_home);
}


void
on_button_kine_quit_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
gtk_main_quit();
}


void
on_button_kine_rdv_clicked (GtkWidget *objet_graphique, gpointer user_data)
{

  GtkWidget *window_kine;
  GtkWidget *window_kine_rdv;
  window_kine = lookup_widget(objet_graphique,"window_kine");
  window_kine_rdv = create_window_kine_rdv();

  GtkWidget *treeview_kine_rdv;
  treeview_kine_rdv = lookup_widget(window_kine_rdv,"treeview_kine_rdv");
  rdv_show(treeview_kine_rdv);
  rdv_widget_hide_all(window_kine_rdv);
  gtk_widget_show(window_kine_rdv);
  gtk_widget_destroy(window_kine);
}

void
on_button_kine_patient_back_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
  GtkWidget *window_kine_patients;
  GtkWidget *window_kine;
  window_kine_patients = lookup_widget(objet_graphique,"window_kine_patients");
  gtk_widget_destroy(window_kine_patients);
  window_kine = create_window_kine();
  gtk_widget_show(window_kine);
}


void
on_button_kine_patients_refresh_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
  GtkWidget *window_kine_patients;
  GtkWidget *treeview_kine_patients;
  window_kine_patients = lookup_widget(objet_graphique,"window_kine_patients");
  treeview_kine_patients = lookup_widget(window_kine_patients,"treeview_kine_patients");
  kine_show_patients(treeview_kine_patients);
}

void
on_button_kine_patients_add_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
GtkWidget *window_kine_patients;
GtkWidget *label_kine_add_patient_1;
GtkWidget *entry_kine_add_patient;
GtkWidget *button_kine_add_patient_validate;
GtkWidget *button_kine_add_patient_end;

window_kine_patients = lookup_widget(objet_graphique,"window_kine_patients");
label_kine_add_patient_1 = lookup_widget(objet_graphique,"label_kine_add_patient_1");
entry_kine_add_patient = lookup_widget(objet_graphique,"entry_kine_add_patient");
button_kine_add_patient_validate = lookup_widget(objet_graphique,"button_kine_add_patient_validate");
button_kine_add_patient_end = lookup_widget(objet_graphique,"button_kine_add_patient_end");

gtk_widget_show(label_kine_add_patient_1);
gtk_widget_show(entry_kine_add_patient);
gtk_widget_show(button_kine_add_patient_validate);
gtk_widget_show(button_kine_add_patient_end);

}


void
on_button_kine_add_patient_validate_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
  char id_str[20], success_str[100];
  int inpt_id,failed;
  GtkWidget *dialog_kine_add_patient;
  GtkWidget *entry_kine_add_patient;
  GtkWidget *label_dialog_kine_add_patient;

  dialog_kine_add_patient = create_dialog_kine_add_patient();
  label_dialog_kine_add_patient = lookup_widget(dialog_kine_add_patient,"label_dialog_kine_add_patient");
  entry_kine_add_patient = lookup_widget(objet_graphique,"entry_kine_add_patient");

  inpt_id = atoi(gtk_entry_get_text(GTK_ENTRY(entry_kine_add_patient)));
  strcpy(id_str,(gtk_entry_get_text(GTK_ENTRY(entry_kine_add_patient))));

  strcpy(success_str,"Succès de l'ajout du patient: \n");
  strcat(success_str,id_str);

  failed = kine_add_patient(inpt_id);

  if(failed == 0){
    strcat(success_str,id_str);
    gtk_label_set_text(GTK_LABEL(label_dialog_kine_add_patient),success_str);
  }
  else if(failed == -1){
    gtk_label_set_text(GTK_LABEL(label_dialog_kine_add_patient),"Erreur : Cet ID n'existe pas dans la base de données !");
  }
  else{
    printf("ERROR: could not add patient.");
    gtk_label_set_text(GTK_LABEL(label_dialog_kine_add_patient),"INTERNAL ERROR : Please retry operation.");
  }

  gtk_widget_show(dialog_kine_add_patient);
}

void
on_button_dialog_kine_add_patient_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
  GtkWidget *dialog;
  dialog = lookup_widget(objet_graphique,"dialog_kine_add_patient");
  gtk_widget_destroy(dialog);
}



void
on_button_kine_add_patient_end_clicked  (GtkWidget *objet_graphique, gpointer user_data)
{
  GtkWidget *window_kine_patients;
  GtkWidget *label_kine_add_patient_1;
  GtkWidget *entry_kine_add_patient;
  GtkWidget *button_kine_add_patient_validate;
  GtkWidget *button_kine_add_patient_end;

  window_kine_patients = lookup_widget(objet_graphique,"window_kine_patients");
  label_kine_add_patient_1 = lookup_widget(window_kine_patients,"label_kine_add_patient_1");
  entry_kine_add_patient = lookup_widget(window_kine_patients,"entry_kine_add_patient");
  button_kine_add_patient_validate = lookup_widget(window_kine_patients,"button_kine_add_patient_validate");
  button_kine_add_patient_end = lookup_widget(window_kine_patients,"button_kine_add_patient_end");

  gtk_widget_hide(label_kine_add_patient_1);
  gtk_widget_hide(entry_kine_add_patient);
  gtk_widget_hide(button_kine_add_patient_validate);
  gtk_widget_hide(button_kine_add_patient_end);
}

void
on_button_nutri_quit_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
  gtk_main_quit();
}


void
on_button_nutri_logout_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
  GtkWidget *window_home;
  GtkWidget *window_nutri;

  window_home = create_window_home();
  window_nutri = lookup_widget(objet_graphique, "window_nutri");

  gtk_widget_destroy(window_nutri);
  gtk_widget_show(window_home);
}

void
on_button_nutri_msg_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
  GtkWidget *window_nutri;
  GtkWidget *window_nutri_msg;

  window_nutri = lookup_widget(objet_graphique,"window_nutri");
  window_nutri_msg = create_window_nutri_msg();

  gtk_widget_destroy(window_nutri);
  gtk_widget_show(window_nutri_msg);
}


void
on_button_nutri_msg_back_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
  GtkWidget *window_nutri;
  GtkWidget *window_nutri_msg;

  window_nutri_msg = lookup_widget(objet_graphique,"window_nutri_msg");
  window_nutri = create_window_nutri();

  gtk_widget_destroy(window_nutri_msg);
  gtk_widget_show(window_nutri);
}

void
on_button_kine_rdv_add_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
  GtkWidget *window_kine_rdv;
  GtkWidget *treeview_kine_rdv_patients;
  window_kine_rdv = lookup_widget(objet_graphique,"window_kine_rdv");
  treeview_kine_rdv_patients = lookup_widget(objet_graphique,"treeview_kine_rdv_patients");
  kine_show_patients(treeview_kine_rdv_patients);

   set_mode(window_kine_rdv, 1);
  rdv_widget_hide_all(window_kine_rdv);
  rdv_widget_add_show(window_kine_rdv);
}

void
on_button_rdv_back_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
  GtkWidget *window_kine;
  GtkWidget *window_kine_rdv;

  window_kine_rdv = lookup_widget(objet_graphique,"window_kine_rdv");
  window_kine = create_window_kine();

  gtk_widget_destroy(window_kine_rdv);
  gtk_widget_show(window_kine);
}

void
on_button_kine_rdv_cancel_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
  GtkWidget *window_kine_rdv;
  window_kine_rdv = lookup_widget(objet_graphique,"window_kine_rdv");
  rdv_widget_hide_all(window_kine_rdv);
}

void
on_button_kine_rdv_refresh_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
  GtkWidget *window_kine_rdv;
  GtkWidget *treeview_kine_rdv;
  window_kine_rdv = lookup_widget(objet_graphique,"window_kine_rdv");
  treeview_kine_rdv = lookup_widget(window_kine_rdv,"treeview_kine_rdv");
  rdv_show(treeview_kine_rdv);
}

void
on_button_kine_rdv_validate_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
  int success;
  char msg[60];
  success = rdv_add(objet_graphique);
  if(success == 0)
    strcpy(msg,"Succès de la création du rendez-vous !");
  else if (success == -1)
    strcpy(msg,"Erreur : Veuillez entrer une ID présente dans la liste !");
  else
    strcpy(msg,"INTERNAL ERROR : please try again");

  GtkWidget *dialog_kine_add_rdv;
  GtkWidget *window_kine_rdv;
  GtkWidget *treeview_kine_rdv;
  GtkWidget *label_dialog_kine_add_rdv;
  dialog_kine_add_rdv =create_dialog_kine_add_rdv();
  label_dialog_kine_add_rdv = lookup_widget(dialog_kine_add_rdv,"label_dialog_kine_add_rdv");
  gtk_label_set_text(GTK_LABEL(label_dialog_kine_add_rdv),msg);
  gtk_widget_show(dialog_kine_add_rdv);
  window_kine_rdv = lookup_widget(objet_graphique,"window_kine_rdv");
  treeview_kine_rdv = lookup_widget(objet_graphique,"treeview_kine_rdv");
  rdv_show(treeview_kine_rdv);

}

void
on_okbutton_dialog_kine_add_rdv_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
    GtkWidget *dialog_kine_add_rdv;
    dialog_kine_add_rdv = lookup_widget(objet_graphique,"dialog_kine_add_rdv");
    gtk_widget_destroy(dialog_kine_add_rdv);
}

void
on_button_kine_rdv_edit_clicked  (GtkWidget *objet_graphique, gpointer user_data)
{
  GtkWidget *window_kine_rdv;
  GtkWidget *treeview_kine_rdv_patients;
  treeview_kine_rdv_patients = lookup_widget(objet_graphique,"treeview_kine_rdv_patients");
  window_kine_rdv = lookup_widget(objet_graphique,"window_kine_rdv");
  kine_show_patients(treeview_kine_rdv_patients);

  set_mode(window_kine_rdv, 2);
  rdv_widget_hide_all(window_kine_rdv);
  rdv_widget_edit_show(window_kine_rdv);

}


void
on_button_kine_rdv_delete_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
 GtkWidget *window_kine_rdv;
 window_kine_rdv = lookup_widget(objet_graphique,"window_kine_rdv");

 set_mode(window_kine_rdv, 3);
 rdv_widget_hide_all(window_kine_rdv);
 rdv_widget_delete_show(window_kine_rdv);
}


void
on_button_kine_validate_delete_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
  GtkWidget *entry;
  GtkWidget *treeview;
  entry = lookup_widget(objet_graphique,"entry_kine_rdv_3");
  char input_id[5];
  strcpy(input_id,gtk_entry_get_text(GTK_ENTRY(entry)));
  rdv_delete(input_id);
  treeview = lookup_widget(objet_graphique,"treeview_kine_rdv");

  GtkWidget *dialog;
  dialog = create_dialog_kine_add_rdv();
  GtkWidget *label;
  label = lookup_widget(dialog,"label_dialog_kine_add_rdv");
  gtk_label_set_text(GTK_LABEL(label),"Succès de la suppression du rendez-vous séléctionné !");
  gtk_widget_show(dialog);
  rdv_show(treeview);

}


void
on_button_kine_rdv_validate_edit_clicked (GtkWidget *objet_graphique, gpointer user_data)
{
  GtkWidget *label;
  GtkWidget *entry;
  GtkWidget *treeview;
  GtkWidget *dialog;

  entry = lookup_widget(objet_graphique,"entry_kine_rdv_3");

  treeview = lookup_widget(objet_graphique,"treeview_kine_rdv");

  rdv_update(objet_graphique);

  dialog = create_dialog_kine_add_rdv();
  label = lookup_widget(dialog,"label_dialog_kine_add_rdv");
  gtk_label_set_text(GTK_LABEL(label),"Succès de la modification du rendez-vous séléctionné !");
  gtk_widget_show(dialog);

  rdv_show(treeview);
}
