#include <gtk/gtk.h>


void
on_button_home_quit_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_home_login_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_admin_logout_clicked  (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_admin_refresh_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_admin_del_clicked  (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_admin_edit_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_admin_add_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_kine_patients_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_kine_logout_clicked  (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_kine_quit_clicked  (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_kine_rdv_clicked  (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_kine_patient_back_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_kine_patients_refresh_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_kine_patients_add_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_kine_add_patient_validate_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_dialog_kine_add_patient_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_kine_add_patient_end_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_nutri_quit_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_nutri_logout_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_nutri_msg_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_nutri_msg_back_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_kine_rdv_add_clicked  (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_rdv_back_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_kine_rdv_cancel_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_kine_rdv_refresh_clicked  (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_kine_rdv_validate_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_okbutton_dialog_kine_add_rdv_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_kine_rdv_edit_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_kine_rdv_delete_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_kine_validate_delete_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_kine_rdv_validate_edit_clicked (GtkWidget *objet_graphique, gpointer user_data);
