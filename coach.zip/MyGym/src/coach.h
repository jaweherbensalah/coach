void coach_ajout_client(int id);
