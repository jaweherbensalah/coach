int kine_add_patient(int id);
void kine_show_patients(GtkWidget *liste);
int isPatient(char idTest[]);
