int check_login(char login[], char password[]);
int check_id(int to_test_id);

typedef struct date date;
struct date {
  int jj;
  int mm;
  int aaaa;
};

typedef struct user user;
struct user {
  int id;
  char nom [20];
  char prenom [20];
  date date_de_naissance;
  char ville [20];
  int postal;
  char adresse [50];
  long tel;
};
